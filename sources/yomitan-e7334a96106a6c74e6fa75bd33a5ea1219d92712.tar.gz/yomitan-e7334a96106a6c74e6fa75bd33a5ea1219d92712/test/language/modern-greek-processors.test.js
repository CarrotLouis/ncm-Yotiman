/*
 * Copyright (C) 2025-2026  Yomitan Authors
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <https://www.gnu.org/licenses/>.
 */

import {describe, expect, test} from 'vitest';
import {removeDoubleAcuteAccentsImpl} from '../../ext/js/language/el/modern-greek-processors.js';

const testCases = [
    ['πρόσωπό', 'πρόσωπο'],
    ['ναΰδριό', 'ναΰδριο'],
    ['ό,τί', 'ό,τι'],
    // Does nothing with less than two acute accents
    ['παιδί', 'παιδί'],
    ['το', 'το'],
    ['ΕΛ.ΑΣ', 'ΕΛ.ΑΣ'],
];

describe('diacritics normalization', () => {
    test.each(testCases)('%s converts to %s', (input, expected) => {
        expect(removeDoubleAcuteAccentsImpl(input)).toStrictEqual(expected);
    });
});
